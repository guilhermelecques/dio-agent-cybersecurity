# Alterações para `AGENTS.md`

**Não substitua o `AGENTS.md` original.** Localize a tabela de skills existente e adicione uma linha seguindo exatamente as colunas e o padrão já utilizados no repositório.

Texto sugerido para a descrição:

| Skill | Quando utilizar |
|---|---|
| `vulnerability-analysis` | Quando o usuário solicitar análise defensiva de vulnerabilidades em código, aplicações ou infraestrutura, incluindo avaliação de risco, correção e validação. |

Se o `AGENTS.md` tiver uma seção/lista de arquivos de conhecimento, acrescente também uma referência a:

- `agent/knowledge/security-basics.md` — conceitos de vulnerabilidade, ameaça, risco, tríade CIA e boas práticas de segurança.

Confira os caminhos e o formato real do `AGENTS.md` antes de salvar. Preserve todas as entradas e instruções originais.
