"""
Laboratório local de SQL Injection.
Uso exclusivamente educacional em um banco SQLite criado nesta pasta.
"""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).with_name("laboratorio.db")


def preparar_banco():
    """Cria a tabela e garante um usuário de teste sem duplicá-lo."""
    with sqlite3.connect(DB_PATH) as conexao:
        conexao.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL UNIQUE,
                senha TEXT NOT NULL
            )
        """)
        conexao.execute(
            "INSERT OR IGNORE INTO usuarios (usuario, senha) VALUES (?, ?)",
            ("admin", "123456")
        )


def login_vulneravel(usuario, senha):
    """Versão intencionalmente vulnerável: não use em aplicações reais."""
    with sqlite3.connect(DB_PATH) as conexao:
        consulta = (
            "SELECT id, usuario FROM usuarios WHERE usuario = '"
            + usuario
            + "' AND senha = '"
            + senha
            + "'"
        )
        return conexao.execute(consulta).fetchone()


def login_seguro(usuario, senha):
    """Versão corrigida: os valores são enviados separadamente da instrução SQL."""
    with sqlite3.connect(DB_PATH) as conexao:
        consulta = """
            SELECT id, usuario
            FROM usuarios
            WHERE usuario = ? AND senha = ?
        """
        return conexao.execute(consulta, (usuario, senha)).fetchone()


def main():
    preparar_banco()
    print("Laboratório local de SQL Injection")
    print("Usuário de teste: admin | Senha: 123456")
    print("\nEscolha a implementação:")
    print("1 - Login vulnerável (demonstração)")
    print("2 - Login corrigido (consultas parametrizadas)")
    opcao = input("Opção: ").strip()

    usuario = input("Usuário: ")
    senha = input("Senha: ")

    if opcao == "1":
        resultado = login_vulneravel(usuario, senha)
        print("\nATENÇÃO: você executou a implementação vulnerável.")
    elif opcao == "2":
        resultado = login_seguro(usuario, senha)
        print("\nVocê executou a implementação corrigida.")
    else:
        print("Opção inválida.")
        return

    print("Login realizado com sucesso!" if resultado else "Usuário ou senha incorretos.")


if __name__ == "__main__":
    main()
