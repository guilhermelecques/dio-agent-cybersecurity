# DIO Agent — Especialização em análise de vulnerabilidades

> **Atenção:** este arquivo é um modelo para a documentação principal. Revise os trechos entre colchetes e só declare como concluídas as atividades que você realmente executou. Integre este conteúdo ao `README.md` original do repositório, preservando créditos e instruções importantes do projeto-base.

## Objetivo

Este projeto estende o DIO Agent com uma especialização em análise defensiva de vulnerabilidades. A proposta é orientar o agente a compreender o contexto e o escopo autorizado, analisar evidências, avaliar impacto, probabilidade e severidade, recomendar correções e explicar como validar a mitigação.

A especialização é feita por instruções, arquivos de conhecimento e skills em Markdown; não envolve treinar um novo modelo.

## O que foi adicionado ou alterado

- `skills/vulnerability-analysis/SKILL.md`: procedimento de análise seguido pelo agente.
- `skills/vulnerability-analysis/README.md`: documentação da skill para pessoas.
- `agent/knowledge/security-basics.md`: conceitos de vulnerabilidade, ameaça, risco, tríade CIA e boas práticas.
- `agent/persona.md`: **[descreva aqui o trecho que você acrescentou à persona original]**.
- `AGENTS.md`: **[descreva aqui a entrada adicionada à tabela de skills e a referência ao conhecimento]**.
- `app.py`: laboratório local didático para comparar uma consulta SQL vulnerável com uma consulta parametrizada.

## Laboratório SQL Injection

O arquivo `app.py` cria um banco SQLite local chamado `laboratorio.db` na mesma pasta. Ele oferece duas opções: uma implementação intencionalmente vulnerável, para demonstração isolada, e uma implementação corrigida que utiliza parâmetros SQL.

Credenciais de teste: usuário `admin`, senha `123456`.

**Execute somente localmente.** A implementação vulnerável é deliberadamente insegura e não deve ser usada em aplicações reais nem exposta à rede.

## Como executar

### Pré-requisitos

- Python 3 instalado.
- Hermes instalado e configurado conforme a documentação oficial.
- Repositório DIO Agent clonado.

### Executar o laboratório

Na pasta que contém `app.py`:

```bash
python app.py
```

Escolha a opção 1 para observar a implementação vulnerável ou a opção 2 para testar a versão parametrizada.

### Executar o agente

Abra o terminal na raiz do repositório DIO Agent e execute:

```bash
hermes
```

A forma como o Hermes carrega arquivos e skills depende da configuração e da integração usada no ambiente. Siga as instruções do README e da documentação da versão instalada. **[Registre aqui o comando/configuração que você efetivamente testou.]**

## Melhoria escolhida

**[Descreva a melhoria que você implementou e testou.]**

Sugestão: padronizar os relatórios com contexto, evidências, impacto, probabilidade, severidade, correção e validação.

## Evidências

Adicione nesta seção imagens reais dos seus testes, por exemplo:

- `evidencias/01-analise-sql-injection.png`
- `evidencias/02-validacao-correcao.png`
- `evidencias/03-perguntas-de-contexto.png`

## Tecnologias

Python, SQLite, Markdown, DIO Agent, Hermes, Git e GitHub.

## Uso responsável

Projeto educacional. Testes devem ocorrer somente em sistemas próprios ou com autorização explícita, respeitando o escopo definido.
