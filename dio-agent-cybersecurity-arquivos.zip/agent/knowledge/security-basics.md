# Fundamentos de segurança da informação

Este arquivo fornece conceitos de referência para análises defensivas. Considere sempre o contexto, as evidências e o escopo autorizado.

## Vulnerabilidade

Fraqueza em software, hardware, configuração ou processo que pode ser explorada e afetar a segurança de um ativo. Exemplo: construir uma consulta SQL concatenando diretamente dados fornecidos pelo usuário.

## Ameaça

Circunstância, evento ou agente capaz de causar dano a um ativo. Uma ameaça pode explorar uma vulnerabilidade, mas ameaça e vulnerabilidade não são sinônimos.

## Risco

Combinação da possibilidade de um evento adverso ocorrer e das consequências que ele pode causar. A avaliação deve considerar o contexto, a exposição, os controles existentes e a qualidade das evidências. Não atribua números sem explicar a escala e as premissas.

## Tríade CIA

- **Confidencialidade:** somente pessoas e sistemas autorizados podem acessar a informação.
- **Integridade:** dados e sistemas permanecem corretos e não são alterados indevidamente.
- **Disponibilidade:** sistemas e informações ficam acessíveis quando necessários.

Uma falha pode afetar mais de uma dimensão da tríade.

## Boas práticas

- Use consultas parametrizadas em vez de concatenar entradas em comandos SQL.
- Valide entradas conforme o formato esperado, sem tratar validação como substituta de parametrização.
- Aplique o princípio do menor privilégio a contas e serviços.
- Armazene senhas com algoritmos apropriados de hash de senha, com salt; nunca em texto puro em aplicações reais.
- Mantenha dependências e sistemas atualizados.
- Proteja segredos e credenciais; não os inclua no código ou no repositório.
- Registre eventos relevantes sem gravar senhas, tokens ou dados sensíveis.
- Faça backup e teste procedimentos de recuperação.
- Teste somente sistemas próprios ou com autorização explícita e escopo definido.

## Análise e classificação

Registre ativo afetado, evidência, condições necessárias para exploração, impacto, probabilidade, controles existentes, severidade e recomendação. Explique os critérios usados. Se faltarem informações, declare a incerteza e pergunte antes de concluir.

## Referências úteis

- OWASP Top 10: https://owasp.org/www-project-top-ten/
- OWASP SQL Injection Prevention Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html
- MITRE ATT&CK: https://attack.mitre.org/

O mapeamento para MITRE ATT&CK depende do cenário. Não associe automaticamente toda SQL Injection a uma técnica específica; explique a correspondência ou informe que não há mapeamento direto adequado.
